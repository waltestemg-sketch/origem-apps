# ORIGEM — site oficial

Esta pasta já está pronta para ser enviada ao repositório GitHub.

## Aplicativos publicados
- FakeWalkGPS 1.0
- Tunnel Lab 4.0.1

## Como adicionar ou atualizar um app depois
1. Coloque o APK em `downloads/`.
2. Coloque o ícone em `assets/apps/NOME_DO_APP/`.
3. Edite somente `data/apps.json`.
4. Faça commit no GitHub.

O `index.html` lê `data/apps.json` automaticamente quando o site está hospedado.
Se o arquivo JSON não puder ser carregado, existe um catálogo de emergência embutido no HTML.

## Cloudflare
Conecte este repositório ao Cloudflare Pages/Workers usando a raiz do projeto como diretório de publicação.
Como é um site estático, não há comando de build obrigatório.

## Segurança
Nunca envie para este repositório:
- senhas;
- tokens da Cloudflare;
- chaves privadas;
- keystore/chave de assinatura dos APKs.
